package br.com.dsm.trabalho_avaliativo_2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrabalhoAvaliativo2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
