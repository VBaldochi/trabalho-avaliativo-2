package br.com.dsm.trabalho_avaliativo_2.model;

import lombok.Data;

@Data	// gera automaticamente os getters e setters
public class Figurinha {
	private String urlImagem;
	private String titulo;
	private String nomeArquivo;
}
